package com.autodidact.rnscrollview;

import android.graphics.drawable.Animatable;
import android.util.Log;
import android.view.View;

import com.autodidact.scroll.FpsListener;
import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.drawee.backends.pipeline.PipelineDraweeControllerBuilder;
import com.facebook.drawee.controller.BaseControllerListener;
import com.facebook.imagepipeline.image.ImageInfo;
import com.facebook.react.uimanager.SimpleViewManager;
import com.facebook.react.uimanager.ThemedReactContext;
import com.facebook.react.views.image.ReactImageView;
import com.facebook.react.views.image.ReactImageManager;

import javax.annotation.Nullable;

import me.relex.photodraweeview.PhotoDraweeView;

public class RNZoomScrollViewManager extends SimpleViewManager<PhotoDraweeView> {
    PipelineDraweeControllerBuilder controller;

    @Override
    public String getName() {
        return "RNZoomScrollView";
    }


    public RNZoomScrollViewManager() {
        super();
    }

    public PhotoDraweeView createViewInstance(ThemedReactContext context) {
        final PhotoDraweeView mPhotoDraweeView = new PhotoDraweeView(context);
        controller = Fresco.newDraweeControllerBuilder();
        controller.setUri("https://firebasestorage.googleapis.com/v0/b/autodidact-mvp.appspot.com/o/items%2F-LcypRd2bM_wGsaKMKtu%2F-LcypRdIZo2kLSjzGLzw%2Foriginal?alt=media&token=e7b4a2b8-81c5-4231-bd6a-f86fdfd0abb6");
        controller.setOldController(mPhotoDraweeView.getController());
        controller.setControllerListener(new BaseControllerListener<ImageInfo>() {
            @Override
            public void onFinalImageSet(String id, ImageInfo imageInfo, Animatable animatable) {
                super.onFinalImageSet(id, imageInfo, animatable);
                if (imageInfo == null || mPhotoDraweeView == null) {
                    return;
                }
                mPhotoDraweeView.update(imageInfo.getWidth(), imageInfo.getHeight());
            }
        });
        mPhotoDraweeView.setController(controller.build());
        mPhotoDraweeView.setMinimumScale(0.5f);
        return mPhotoDraweeView;
    }
/*
    @Override
    public void addView(ZoomageView parent, View child, int index) {
        g.addView(child, index);
    }

    @ReactProp(name = "minimumZoomScale", defaultFloat = 0.75f)
    public void setMinimumZoomScale(ZoomageView view, float value) {
        zoomHandler.setMinZoom(value);
    }

    @ReactProp(name = "maximumZoomScale", defaultFloat = 3.0f)
    public void setMaximumZoomScale(ZoomageView view, float value) {
        Log.d("ScrollV", "setMaximumZoomScale: " + value);
        Log.d("ScrollV", "setMaximumZoomScale View: " + zoomHandler.toString());
        zoomHandler.setMaxZoom(value);
    }
/*
    @Override
    public void addViews(ZoomageView parent, List<View> views) {
        Log.d("ScrollV", "addViews: " + parent.toString() + "    child:  " + views.toString());
        super.addViews(g, views);
    }

    /*
                        @Override
                        public ZoomageView createViewInstance(ThemedReactContext context) {
                            return new ReactZoomScrollView(context);
                        }

                    /*
                        @ReactProp(name = PROPS_MATH_TEXT)
                        public void setMathText(RNMathView viewContainer, String text) {
                            //String r = text.getString(0).replaceAll("###", "\\\\");
                            viewContainer.setText(text);
                        }
                    */

}
