package com.autodidact.rnscrollview;

public class ScaleUtility {
    public static float clamp(final float min, final float value, final float max) {
        return Math.max(min, Math.min(value, max));
    }

    public static float lerp(final float a, final float b, final float k) {
        return a + (b - a) * k;
    }

    public static float bias(final float a, final float b, final float k) {
        return Math.abs(b - a) >= k ? a + k * Math.signum(b - a) : b;
    }
}
