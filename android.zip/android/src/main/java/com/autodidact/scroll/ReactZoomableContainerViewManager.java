// Copyright (c) 2004-present, Facebook, Inc.

// This source code is licensed under the MIT license found in the
// LICENSE file in the root directory of this source tree.

package com.autodidact.scroll;

import android.view.ViewGroup;

import com.facebook.react.module.annotations.ReactModule;
import com.facebook.react.uimanager.ThemedReactContext;
import com.facebook.react.uimanager.ViewGroupManager;
import com.facebook.react.uimanager.annotations.ReactProp;

/** View manager for {@link ReactZoomableContainerView} components. */
@ReactModule(name = ReactZoomableContainerViewManager.REACT_CLASS)
public class ReactZoomableContainerViewManager
    extends ViewGroupManager<ReactZoomableContainerView> {

  protected static final String REACT_CLASS = "AndroidZoomableContentView";

  public ReactZoomableContainerViewManager() {}

  @Override
  public String getName() {
    return REACT_CLASS;
  }

  @Override
  public ReactZoomableContainerView createViewInstance(ThemedReactContext context) {
    ReactZoomableContainerView v = new ReactZoomableContainerView(context);
    final ReactScrollView scrollView = ((ReactScrollView) v.getParent());
    v.setListner(new ReactZoomableContainerView.ZoomViewListener() {
      @Override
      public void onZoomStarted(float zoom, float zoomx, float zoomy) {
        ReactScrollViewHelper.emitScrollBeginDragEvent(scrollView);
      }

      @Override
      public void onZooming(float zoom, float zoomx, float zoomy) {
        ReactScrollViewHelper.emitScrollEvent(scrollView, scrollView.mVelocityHelper.getXVelocity(),scrollView.mVelocityHelper.getYVelocity());
      }

      @Override
      public void onZoomEnded(float zoom, float zoomx, float zoomy) {
        ReactScrollViewHelper.emitScrollEndDragEvent(scrollView, scrollView.mVelocityHelper.getXVelocity(),scrollView.mVelocityHelper.getYVelocity());
        ViewGroup.LayoutParams layoutParams = scrollView.getLayoutParams();
        layoutParams.width *= zoomx;
        layoutParams.height *= zoomy;
        scrollView.setLayoutParams(layoutParams);
      }
    });

    return v;
  }

  @ReactProp(name = "minimumZoomScale", defaultFloat = 0.75f)
  public void setMinimumZoomScale(ReactZoomableContainerView view, float value) {
    //view.setScrollEnabled(value);
  }

  @ReactProp(name = "maximumZoomScale", defaultFloat = 3.0f)
  public void setMaximumZoomScale(ReactZoomableContainerView view, float value) {
    view.setMaxZoom(value);
  }
}
