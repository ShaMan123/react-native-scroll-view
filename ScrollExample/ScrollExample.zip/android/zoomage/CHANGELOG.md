# Zoomage Change Log

## 1.0.0 (2016-04-01)
- Initial release

## 1.1.0 (2017-04-21)
- Remove double-tap zoom functionality
- Added zoomage_ prefix to xml variables to avoid potential conflicts
- Some few minor fixes and cleanup

## 1.2.0 (2018-09-13)
- Add new double tap to zoom
- Fix some minor issues