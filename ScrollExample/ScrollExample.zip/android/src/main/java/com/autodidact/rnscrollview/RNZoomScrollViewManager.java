package com.autodidact.rnscrollview;

import android.util.Log;
import android.view.View;

import com.facebook.react.uimanager.ThemedReactContext;
import com.facebook.react.uimanager.ViewGroupManager;
import com.facebook.react.uimanager.annotations.ReactProp;
import com.facebook.react.views.scroll.FpsListener;
import com.facebook.react.views.scroll.ReactScrollView;
import com.facebook.react.views.scroll.ReactScrollViewManager;
import com.facebook.react.views.view.ReactViewGroup;
import com.jsibbold.zoomage.ZoomageView;

import javax.annotation.Nullable;

public class RNZoomScrollViewManager extends ViewGroupManager<ZoomageView> {
    protected @Nullable FpsListener mFpsListener = null;
    private ReactScrollViewManager scrollViewManager;
    private ReactScrollView scrollView;
    private ReactViewGroup g;
    private ZoomageView zoomHandler;

    @Override
    public String getName() {
        return "RNZoomScrollView";
    }


    public RNZoomScrollViewManager(@Nullable FpsListener fpsListener) {
        //super(fpsListener);
        super();
        mFpsListener = fpsListener;
    }

    public ZoomageView createViewInstance(ThemedReactContext context) {
        //scrollViewManager.createViewInstance(context);

        g = new ReactViewGroup(context);
        //zoomHandler = new ZoomageView(context);
        //zoomHandler.addView(g);
        return new ZoomageView(context);
    }
/*
    @Override
    public void addView(ZoomageView parent, View child, int index) {
        g.addView(child, index);
    }

    @ReactProp(name = "minimumZoomScale", defaultFloat = 0.75f)
    public void setMinimumZoomScale(ZoomageView view, float value) {
        zoomHandler.setMinZoom(value);
    }

    @ReactProp(name = "maximumZoomScale", defaultFloat = 3.0f)
    public void setMaximumZoomScale(ZoomageView view, float value) {
        Log.d("ScrollV", "setMaximumZoomScale: " + value);
        Log.d("ScrollV", "setMaximumZoomScale View: " + zoomHandler.toString());
        zoomHandler.setMaxZoom(value);
    }
/*
    @Override
    public void addViews(ZoomageView parent, List<View> views) {
        Log.d("ScrollV", "addViews: " + parent.toString() + "    child:  " + views.toString());
        super.addViews(g, views);
    }

    /*
                        @Override
                        public ZoomageView createViewInstance(ThemedReactContext context) {
                            return new ReactZoomScrollView(context);
                        }

                    /*
                        @ReactProp(name = PROPS_MATH_TEXT)
                        public void setMathText(RNMathView viewContainer, String text) {
                            //String r = text.getString(0).replaceAll("###", "\\\\");
                            viewContainer.setText(text);
                        }
                    */

}
