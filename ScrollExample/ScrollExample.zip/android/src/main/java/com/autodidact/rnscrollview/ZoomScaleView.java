package com.autodidact.rnscrollview;

import android.animation.Animator;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import com.facebook.react.bridge.ReactContext;
import com.facebook.react.views.view.ReactViewGroup;

public class ZoomScaleView extends ReactViewGroup {
    private ScaleGestureDetector mScaleGestureDetector;
    private float mScaleFactor = 1.0f;
    private float minScale = 0.75f;
    private float maxScale = 3.0f;

    public ZoomScaleView(ReactContext context){
        super(context);
        mScaleGestureDetector = new ScaleGestureDetector(context, new ScaleListener());
    }

    public void setMinimumZoomScale(float value){
        minScale = value;
    }

    public void setMaximumZoomScale(float value){
        maxScale = value;
    }

    private float clamp(float value){
        return ScaleUtility.clamp(minScale, value, maxScale);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        mScaleGestureDetector.onTouchEvent(motionEvent);
        return true;
    }

    private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
        @Override
        public boolean onScale(ScaleGestureDetector scaleGestureDetector){
            mScaleFactor = clamp(mScaleFactor * scaleGestureDetector.getScaleFactor());
            setScaleX(mScaleFactor);
            setScaleY(mScaleFactor);
            return true;
        }
    }
}
