package com.autodidact.rnscrollview;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;

import com.facebook.react.common.MapBuilder;
import com.facebook.react.uimanager.SimpleViewManager;
import com.facebook.react.uimanager.ThemedReactContext;
import com.facebook.react.uimanager.ViewGroupManager;
import com.facebook.react.uimanager.annotations.ReactProp;
import com.facebook.react.views.scroll.FpsListener;
import com.facebook.react.views.scroll.ReactScrollView;
import com.facebook.react.views.scroll.ReactScrollViewManager;
import com.facebook.react.views.view.ReactViewGroup;
import com.facebook.react.views.view.ReactViewManager;

import java.util.List;
import java.util.Map;

import javax.annotation.Nullable;

public class RNZoomScrollViewManager0 extends ViewGroupManager<ZoomScaleView> {
    protected @Nullable FpsListener mFpsListener = null;
    private ReactScrollViewManager scrollViewManager;
    private ReactScrollView scrollView;
    private ReactViewGroup g;
    private ZoomScaleView zoomHandler;

    @Override
    public String getName() {
        return "RNZoomScrollView";
    }


    public RNZoomScrollViewManager0(@Nullable FpsListener fpsListener) {
        //super(fpsListener);
        super();
        mFpsListener = fpsListener;
    }

    public ZoomScaleView createViewInstance(ThemedReactContext context) {
        return new ZoomScaleView(context);
    }

    @ReactProp(name = "minimumZoomScale", defaultFloat = 0.75f)
    public void setMinimumZoomScale(ZoomScaleView view, float value) {
        view.setMinimumZoomScale(value);
    }

    @ReactProp(name = "maximumZoomScale", defaultFloat = 3.0f)
    public void setMaximumZoomScale(ZoomScaleView view, float value) {
        view.setMaximumZoomScale(value);
    }
/*
    @Override
    public void addViews(ZoomScaleView parent, List<View> views) {
        Log.d("ScrollV", "addViews: " + parent.toString() + "    child:  " + views.toString());
        super.addViews(g, views);
    }

    /*
                        @Override
                        public ZoomScaleView createViewInstance(ThemedReactContext context) {
                            return new ReactZoomScrollView(context);
                        }

                    /*
                        @ReactProp(name = PROPS_MATH_TEXT)
                        public void setMathText(RNMathView viewContainer, String text) {
                            //String r = text.getString(0).replaceAll("###", "\\\\");
                            viewContainer.setText(text);
                        }
                    */

}
